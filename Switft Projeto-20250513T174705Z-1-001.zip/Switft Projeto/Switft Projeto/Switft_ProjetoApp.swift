//
//  Switft_ProjetoApp.swift
//  Switft Projeto
//
//  Created by Turma01-16 on 24/10/24.
//

import SwiftUI

@main
struct Switft_ProjetoApp: App {
    var body: some Scene {
        
        
        
        
        
        WindowGroup {
            ContentView()
        }
    }
}
