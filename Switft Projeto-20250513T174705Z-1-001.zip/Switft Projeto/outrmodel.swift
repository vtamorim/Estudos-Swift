import Foundation


struct agua:Decodable, Hashable{
 //   var id: Int?
    var umidade: String?
}
