//
//  resultapi.swift
//  Switft Projeto
//
//  Created by Turma01-16 on 04/11/24.
//

import SwiftUI

struct resultapi: View {
    var body: some View {
        Text(/*@START_MENU_TOKEN@*/"Hello, World!"/*@END_MENU_TOKEN@*/)
    }
}

#Preview {
    resultapi()
}
