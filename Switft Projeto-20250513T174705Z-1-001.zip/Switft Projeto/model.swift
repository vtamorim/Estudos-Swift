//
//  model.swift
//  Switft Projeto
//
//  Created by Turma01-16 on 04/11/24.
//

import Foundation


struct wow:Decodable, Hashable{
 //   var id: Int?
    var name: String?
    var star: Double?
    var category: String?
    var image: String?
}
